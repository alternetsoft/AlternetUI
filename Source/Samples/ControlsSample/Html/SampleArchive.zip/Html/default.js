﻿// This is commented text

function fn2(s)
{
    alert("Panda says hello!");
}
